<?php
require_once("../autoloader.php");
require_once("../routes/web.php");
?>
